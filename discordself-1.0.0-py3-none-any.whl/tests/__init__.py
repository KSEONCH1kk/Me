"""Тесты для DiscordSelf библиотеки"""

